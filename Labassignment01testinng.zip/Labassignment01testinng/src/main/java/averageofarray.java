import org.junit.jupiter.api.*;

import java.util.Scanner;
public class averageofarray {
    public static void main(String[] args)
    {
        int n, sum = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int a[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            a[i] = s.nextInt();
            sum = sum + a[i];
        }
        System.out.println("Sum:"+sum);
        average(sum,n);

    }
    public static float average(int sum, int num){
        float average = (float)sum / num;
        System.out.println("Average:"+average);
        return average;
    }
    @Test
    public void testforaverageoutput() {
        float result = average(30,3);
        float expected = 10;
        Assertions.assertEquals(expected,result);
    }


}
