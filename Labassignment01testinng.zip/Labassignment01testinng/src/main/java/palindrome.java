import java.util.Scanner;
import org.junit.jupiter.api.*;
public class palindrome {
    public static void main(String args[])
    {
        String str1,str2;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first string:");
        str1 = sc.nextLine();
        System.out.println("Enter second string:");
        str2 = sc.nextLine();

        if (isPalindrome(str1) == true && isPalindrome(str2) == false)
            System.out.println(str1+" is a palindrome and "+str2+" is not");
        else
            if (isPalindrome(str1) == true && isPalindrome(str2) == true)
                System.out.println(str1 + " is a palindrome and " + str2 + " is also palindrome");
        else
            if (isPalindrome(str1) == false && isPalindrome(str2) == true)
                System.out.println(str1+" is not palindrome and "+str2+" is palindrome");
            else
             System.out.println(str1+" and "+str2+ " is not a palindrome");

    }
    static boolean isPalindrome(String str)
    {
        int i = 0, j = str.length() - 1;
        while (i < j) {
            if (str.charAt(i) != str.charAt(j))
                return false;
            i++;
            j--;
        }
        return true;
    }
    @Test
    public void testIsPalindrome() {
        boolean result = isPalindrome("aba");
        boolean expected = true;
        Assertions.assertEquals(expected,result);
    }
    @Test
    public void testIsNotPalindrome() {
        boolean result = isPalindrome("dfs");
        boolean expected = false;
        Assertions.assertEquals(expected,result);
    }
    @Test
    public void testIsNotPalindromewithwhitespace() {
        boolean result = isPalindrome("dfsf d");
        boolean expected = false;
        Assertions.assertEquals(expected,result);
    }
    @Test
    public void testIsPalindromewithwhitespace() {
        boolean result = isPalindrome("a b a");
        boolean expected = true;
        Assertions.assertEquals(expected,result);
    }

}
