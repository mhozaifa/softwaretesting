
import org.junit.jupiter.api.*;

import java.util.Scanner;
public class primenumimpletation {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a number : ");
        int n = s.nextInt();
        if (isPrime(n)) {
            System.out.println(n + " is a prime number");
        } else {
            System.out.println(n + " is not a prime number");
        }
    }

    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i < Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    @Test
    public void testIsPrime() {
        boolean result = isPrime(56);
        boolean expected = false;
        Assertions.assertEquals(expected,result);
    }
    @Test
    public void testIsNotPrime() {
        boolean result = isPrime(67);
        boolean expected = true;
        Assertions.assertEquals(expected,result);
    }
}