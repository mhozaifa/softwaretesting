import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Scanner;

public class celsustofarenhite {
    public static void main (String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter temperature in Celsius: ");
        float C = in.nextFloat();
        System .out.println ("Temperature in Kelvin ( K ) = " + Celsius_to_Kelvin(C));
        System.out.println(" Temperature in Fahrenheit ( F ) = " + Celsius_to_Farenhite(C));
    }
    static float Celsius_to_Kelvin(float C)
    {
        return (float)(C + 273.15);
    }
    static float Celsius_to_Farenhite(float C){
        return (float)(C * (9f / 5) + 32);
    }
    @Test
    public void testIstoKelvin() {
        float result = Celsius_to_Kelvin(90);
        float expected = (float) 363.15;
        Assertions.assertEquals(expected,result);
    }
    @Test
    public void testIstoFagrenhite() {
        float result = Celsius_to_Farenhite(90);
        float expected = (float) 194.0;
        Assertions.assertEquals(expected,result);
    }
}
