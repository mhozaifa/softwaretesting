
import org.junit.jupiter.api.*;

import java.util.Scanner;
public class evenodd {

    public static void main(String args[])
    {
        int num;
        System.out.println("Enter an Integer number:");

        //The input provided by user is stored in num
        Scanner input = new Scanner(System.in);
        num = input.nextInt();
    }

    public static boolean isEven(int n){
            if ( n % 2 == 0 ){
                System.out.println("Entered number is even");
                return true;
            }
            else
                return false;
        }


    @Test
    public void testIsEven() {
        boolean result = isEven(6);
        boolean expected = true;
        Assertions.assertEquals(expected,result);
    }
    @Test
    public void testIsOdd() {
        boolean result = isEven(7);
        boolean expected = false;
        Assertions.assertEquals(expected,result);
    }
}